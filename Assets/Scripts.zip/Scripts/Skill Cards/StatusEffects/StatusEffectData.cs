using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Serialization;

public abstract class StatusEffectData : ScriptableObject
{
    public static readonly Dictionary<StatusEffectData, string> ColorHexMap = new();
    
    public string name;
    [TextArea]
    public string description;
    public Sprite sprite;
    public Color color;
    public float damageMarkerSizeMult = 1;
    public bool damageMarkerPunchEffect;
    public abstract void Execute(HitData hitData);
    protected virtual void OnEnable()
    {
        string hex = $"#{ColorUtility.ToHtmlStringRGB(color)}";
        if (!ColorHexMap.ContainsKey(this))
            ColorHexMap[this] = hex;
        else
            ColorHexMap[this] = hex; 
    }
}