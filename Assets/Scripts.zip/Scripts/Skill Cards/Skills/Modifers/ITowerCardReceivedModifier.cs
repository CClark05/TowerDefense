public interface ITowerCardReceivedModifier 
{
    public void Modify(TowerWaveData towerWaveData);
}