public interface ITowerCardRemovedModifier 
{
    public void Modify(TowerWaveData towerWaveData);
}