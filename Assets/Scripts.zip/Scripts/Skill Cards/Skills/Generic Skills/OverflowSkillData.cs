using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Overflow Data", menuName = "SkillData/Generic/Overflow")]
public class OverflowSkillData : SkillData
{
    public int extraSlots;

    private void OnValidate()
    {
        description = $"Gives +{extraSlots} card slots.";
    }

    public override SkillInstance CreateInstance()
    {
        return new OverflowSkillInstance(this);
    }
}

public class OverflowSkillInstance : SkillInstance<OverflowSkillData>, ITowerCardReceivedModifier, ITowerCardRemovedModifier
{
    public OverflowSkillInstance(OverflowSkillData data) : base(data)
    {
    }

    void ITowerCardReceivedModifier.Modify(TowerWaveData towerWaveData)
    {
        towerWaveData.increasedSlots += Data.extraSlots;
    }

    void ITowerCardRemovedModifier.Modify(TowerWaveData towerWaveData)
    {
        towerWaveData.increasedSlots -= Data.extraSlots;
    }
}