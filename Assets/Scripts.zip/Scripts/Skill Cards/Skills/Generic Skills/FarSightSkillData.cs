using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Far Sight Data", menuName = "SkillData/Generic/FarSight")]
public class FarSightSkillData : SkillData
{
    public int increasedRange;

    private void OnValidate()
    {
        description = $"Gives +{increasedRange} range.";
    }

    public override SkillInstance CreateInstance()
    {
        return new FarSightSkillInstance(this);
    }
}

public class FarSightSkillInstance : SkillInstance<FarSightSkillData>, ITowerCardReceivedModifier, ITowerCardRemovedModifier
{
    public FarSightSkillInstance(FarSightSkillData data) : base(data)
    {
    }
    void ITowerCardReceivedModifier.Modify(TowerWaveData towerWaveData)
    {
        towerWaveData.increasedRange += Data.increasedRange;
    }

    void ITowerCardRemovedModifier.Modify(TowerWaveData towerWaveData)
    {
        towerWaveData.increasedRange -= Data.increasedRange;
    }
}