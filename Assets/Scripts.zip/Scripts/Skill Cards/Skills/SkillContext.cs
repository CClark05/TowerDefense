using System;
using System.Collections.Generic;
using System.Linq;

public class SkillContext
{
    public List<SkillInstance> ActiveSkills { get; private set; } = new();
    public TowerDataHolder Tower { get; private set; } = new();
    public event Action<SkillInstance> OnCardInstanceCreated;
    public event Action<TowerWaveData> OnTowerUpdated;
    public SkillContext(TowerDataHolder tower)
    {
        Tower = tower;
    }
    public void AddSkill(SkillData skillData)
    {
        var instance = skillData.CreateInstance();
        ActiveSkills.Add(instance);
        instance.SetContext(this);
        TowerWaveData towerWaveData = new TowerWaveData();
        OnCardInstanceCreated?.Invoke(instance);
        if (TowerService.TryModifyOnCardReceived(towerWaveData, instance))
            OnTowerUpdated?.Invoke(towerWaveData);
        
    }

    public bool TryRemoveSkill(SkillData skillData)
    {
        var instance = ActiveSkills.LastOrDefault(s => s.Data == skillData);
        if (instance == null) return false;
        var towerWaveData = new TowerWaveData();
        if (TowerService.TryModifyOnCardRemoved(towerWaveData, instance))
            OnTowerUpdated?.Invoke(towerWaveData);
        return true;
    }
    public IEnumerable<T> GetSkillsOfType<T>()
    {
        return ActiveSkills.OfType<T>();
    }

    public bool HasSkill<T>() where T : SkillInstance
    {
        return ActiveSkills.Any(s => s is T);
    }

    public SkillInstance GetSkill(System.Type type)
    {
        return ActiveSkills.FirstOrDefault(s => s.GetType() == type);
    }
    public IEnumerable<(SkillInstance instance, T modifier)> GetSkillInstancesWith<T>() where T : class
    {
        foreach (var instance in ActiveSkills)
            if (instance is T t)
                yield return (instance, t);  
    }
}
