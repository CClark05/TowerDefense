using System;
using System.Collections.Generic;
using UnityEngine;
[CreateAssetMenu(fileName = "Lucky Draw Data", menuName = "SkillData/Lucky/LuckyDraw")]
public class LuckyDrawSkillData : SkillData
{
    //10% - deal no damage
    //25% - deal 50% damage 
    //30% - deal 1x damage
    //25% - deal 2x damage
    //10% - deal 5x damage
    [Serializable]
    public class RandomDamageData
    {
        
        [Range(0f, 1f)] public float probability;
        public float multiplier;
    }

    public Color color;
    public List<RandomDamageData> DamageData = new();
    public override SkillInstance CreateInstance()
    {
        return new LuckyDrawSkillInstance(this);
    }
}

public class LuckyDrawSkillInstance : SkillInstance<LuckyDrawSkillData>, IHitModifier
{
    private LuckyDrawSkillData data;


    public void Modify(HitData hitData, IDamageable target)
    {
        float roll = UnityEngine.Random.value;
        float cumulative = 0f;

        foreach (var tier in data.DamageData)
        {
            cumulative += tier.probability;
            if (roll <= cumulative)
            {
                hitData.finalDamage = Mathf.FloorToInt(hitData.finalDamage * tier.multiplier);
                if (tier.multiplier > 1)
                {
                    hitData.damageMarkerPunchEffect = true;
                    hitData.colors.Add(data.color);
                    hitData.damageMarkerSizeMult = tier.multiplier >= 5 ? 3 : 2;
                }
                return;
            }
        }
        
        Debug.LogError("Lucky Draw random probabilities not equal to 1");

    }

    public IHitModifier.Priority priority => IHitModifier.Priority.MultDamage;

    public LuckyDrawSkillInstance(LuckyDrawSkillData data) : base(data)
    {
    }
}
