using UnityEngine;

public interface IUsesMana
{
    public ManaSystem ManaSystem { get; }
}
public class ManaSystem
{
    public int MaxMana { get; private set; }
    public int CurrentMana { get; private set; }

    public ManaSystem(int maxMana)
    {
        MaxMana = maxMana;
        CurrentMana = 0;
    }

    public void RefillMana () => CurrentMana = MaxMana;

    public bool HasMaxMana => CurrentMana >= MaxMana;
    public void UseMana() => CurrentMana = 0;
    public void GainMana(int amount)
    {
        CurrentMana = Mathf.Min(CurrentMana + amount, MaxMana);
    }
}