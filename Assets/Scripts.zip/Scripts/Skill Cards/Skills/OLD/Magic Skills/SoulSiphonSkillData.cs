using System.Linq;
using UnityEngine;

[CreateAssetMenu(fileName = "Soul Siphon Data", menuName = "SkillData/Magic/Soul Siphon")]
public class SoulSiphonSkillData : SkillData
{
    public override SkillInstance CreateInstance()
    {
        return new SoulSiphonSkillInstance(this);
    }
}

public class SoulSiphonSkillInstance : SkillInstance<SoulSiphonSkillData>, IOnHit
{
    private SoulSiphonSkillData skillData;

    public void OnHit(HitData hitData)
    {
        if (hitData.didKill)
        {
            Debug.Log("soul siphon");
            var mana = skillContext.GetSkillsOfType<IUsesMana>().FirstOrDefault();
            mana.ManaSystem.RefillMana();
        }
    }

    public int Priority { get; }

    public SoulSiphonSkillInstance(SoulSiphonSkillData data) : base(data)
    {
    }
}