using System;
using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
[CreateAssetMenu(fileName = "Arcanic Detonation Data", menuName = "SkillData/Magic/Arcanic Detonation")]
public class ArcanicDetonationSkillData : SkillData
{
    [SerializeField] private float detonateTime = 2;
    [SerializeField] private float damageMult = 2;
    public float DetonateTime => detonateTime;
    public float DamageMult => damageMult;

    private void OnValidate()
    {
        description = $"<color={StatusEffectData.ColorHexMap[statusEffects[0]]}>Empowered</color> shots detonate after {detonateTime} seconds for {damageMult}x damage.";
    }

    public override SkillInstance CreateInstance()
    {
        return new ArcanicDetonationSkillInstance(this);
    }
}

public class ArcanicDetonationSkillInstance : SkillInstance<ArcanicDetonationSkillData>, IOnHit
{
    private ArcanicDetonationSkillData skillData;
    
    public void OnHit(HitData hitData)
    {
        bool hasEmpowered = hitData.effectsApplied.Any(e => e is EmpoweredStatusEffect);
        if (!hasEmpowered)
            return;
        Debug.Log("Arcanic Detonation");
        hitData.DelayDamage?.Invoke(skillData.DetonateTime, skillData.DamageMult);
    }

    public int Priority { get; } = 1;

    public ArcanicDetonationSkillInstance(ArcanicDetonationSkillData data) : base(data)
    {
    }
}