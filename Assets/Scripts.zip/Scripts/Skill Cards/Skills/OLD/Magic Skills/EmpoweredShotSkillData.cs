using System;
using System.Linq;
using Unity.VisualScripting;
using UnityEditor;
using UnityEngine;
using ColorUtility = UnityEngine.ColorUtility;

[CreateAssetMenu(fileName = "Empowered Shot Data", menuName = "SkillData/Magic/Empowered Shot")]
public class EmpoweredShotSkillData : SkillData
{
    [SerializeField] private int manaRequirement = 100; //keep at 100
    [SerializeField] private int manaPerHit;
    public int ManaRequirement => manaRequirement;
    public int ManaPerHit => manaPerHit;

    private void OnValidate()
    {
        string hex = ColorUtility.ToHtmlStringRGB(statusEffects[0].color);
        description = $"Each hit builds {manaPerHit}% of mana bar. Once mana bar is full next shot is <color=#{hex}>Empowered</color>.";
    }

    public override SkillInstance CreateInstance()
    {
        return new EmpoweredShotSkillInstance(this);
    }
    
}
public class EmpoweredShotSkillInstance : SkillInstance<EmpoweredShotSkillData>, IUsesMana, IOnHit
{
    private EmpoweredShotSkillData skillData;
    public ManaSystem ManaSystem { get; }

    
    public void OnHit(HitData hitData)
    {
        ManaSystem.GainMana(skillData.ManaPerHit);
        if (ManaSystem.HasMaxMana)
        {
            Debug.Log("Empowered Hit");
            skillData.statusEffects[0].Execute(hitData);
            ManaSystem.UseMana();
        }
    }

    public EmpoweredShotSkillInstance(EmpoweredShotSkillData data) : base(data)
    {
        ManaSystem = new ManaSystem(skillData.ManaRequirement);
    }
}

