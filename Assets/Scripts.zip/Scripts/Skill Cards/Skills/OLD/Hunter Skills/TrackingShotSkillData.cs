using System;
using UnityEngine;

[CreateAssetMenu(fileName = "Tracking Shot Data", menuName = "SkillData/Hunter/Tracking Shot")]
public class TrackingShotSkillData : SkillData
{
    private void OnValidate()
    {
        string hex = StatusEffectData.ColorHexMap[statusEffects[0]];
        description = $"Shots inflict <color={hex}>Tracked</color>.";
    }

    public override SkillInstance CreateInstance()
    {
        return new TrackingShotSkillInstance(this);
    }
}

public class TrackingShotSkillInstance : SkillInstance<TrackingShotSkillData>, IOnHit
{
    private TrackingShotSkillData data;
    private bool delayDamage;
    

    public void OnHit(HitData hitData)
    {
        Debug.Log("Tracking Shot");
        data.statusEffects[0].Execute(hitData);
    }


    public TrackingShotSkillInstance(TrackingShotSkillData data) : base(data)
    {
    }
}
