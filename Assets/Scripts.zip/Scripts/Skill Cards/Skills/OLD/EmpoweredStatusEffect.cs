using UnityEngine;

[CreateAssetMenu(fileName = "EmpoweredStatusEffect", menuName = "StatusEffects/Empowered")]
public class EmpoweredStatusEffect : StatusEffectData, IHitModifier
{
    [SerializeField] private float damageMult = 2;
    public override void Execute(HitData hitData)
    {
        hitData.effectsApplied.Add(this);
    }
    public void Modify(HitData hitData, IDamageable target)
    {
        hitData.colors.Add(color);
        hitData.damageMarkerSizeMult = damageMarkerSizeMult;
        hitData.finalDamage = Mathf.FloorToInt(hitData.finalDamage * damageMult);
        hitData.damageMarkerPunchEffect = damageMarkerPunchEffect;
    }

    public IHitModifier.Priority priority => IHitModifier.Priority.MultDamage;
}