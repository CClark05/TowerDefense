using UnityEngine;
using ColorUtility = UnityEngine.ColorUtility;

[CreateAssetMenu(fileName = "TrackedStatusEffect", menuName = "StatusEffects/Tracked")]
public class TrackedStatusEffect : OnHitStatusEffect, IHitModifier
{
    [SerializeField] private float critChance = 0.1f;
    [SerializeField] private int critMult = 3;
    
    private void OnValidate()
    {
        string hex = ColorUtility.ToHtmlStringRGB(color);
        description =
            $"<color=#{hex}>Tracked</color> enemies can take {critMult}x critical damage. Each each time <color=#{hex}>Tracked</color> is applied +{critChance * 100}% chance to take critical damage.";
    }

    public override void Execute(HitData hitData)
    {
        hitData.effectsApplied.Add(this);
    }

    public override void OnPersistentHit(HitData hitData, int stacks)
    {
        //hitData.isCrit = UnityEngine.Random.value < this.critChance * stacks;
    }

    public void Modify(HitData hitData, IDamageable target)
    {
        //if (!hitData.isCrit) return;
        Debug.Log("crit");
        hitData.colors.Add(color);
        hitData.damageMarkerPunchEffect = damageMarkerPunchEffect;
        hitData.damageMarkerSizeMult = damageMarkerSizeMult;
        hitData.finalDamage = Mathf.FloorToInt(hitData.finalDamage * critMult);
    }

    public IHitModifier.Priority priority => IHitModifier.Priority.MultDamage;
}