using System;
using System.Collections;
using System.Linq;
using UnityEngine;
[CreateAssetMenu(fileName = "Critical Resonance Data", menuName = "SkillData/Synergy/Critical Resonance")]
public class CriticalResonanceSkillData : SkillData
{
    public float RetriggerMult = 0.5f;
    private void OnValidate()
    {
        string hex = ColorUtility.ToHtmlStringRGB(statusEffects[0].color);
        description = $"If a hit is both Critical and <color=#{hex}>Empowered</color>, it retriggers immediately for 50% damage.";
    }

    public override SkillInstance CreateInstance()
    {
        return new CriticalResonanceSkillInstance(this);
    }
}

public class CriticalResonanceSkillInstance : SkillInstance<CriticalResonanceSkillData>, IHitModifier
{
    private CriticalResonanceSkillData data;

    public void Modify(HitData hitData, IDamageable target)
    {
        if (hitData.effectsApplied.Any(effect => effect is EmpoweredStatusEffect))
        {
            IEnumerator WaitAndRetrigger()
            {
                yield return new WaitUntil(() => hitData.RetriggerDamage != null);
                hitData.RetriggerDamage.Invoke(data.RetriggerMult);
            }
            CoroutineRunner.Instance.StartCoroutine(WaitAndRetrigger());
        }
    }

    public IHitModifier.Priority priority => IHitModifier.Priority.MultDamage;

    public CriticalResonanceSkillInstance(CriticalResonanceSkillData data) : base(data)
    {
    }
}
