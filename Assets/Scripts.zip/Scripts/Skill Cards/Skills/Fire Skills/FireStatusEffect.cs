using UnityEngine;

[CreateAssetMenu(fileName = "Fire Status Effect", menuName = "StatusEffects/Fire")]
public class FireStatusEffect : OnTickStatusEffect
{
    public int damagePerTick = 1;

    private void OnValidate()
    {
        description = $"Each stack deals {damagePerTick} damage per second.";
    }

    public override void Execute(HitData hitData)
    {
        hitData.effectsApplied.Add(this);
    }

    public override void OnTick(TickData tickData, int stacks)
    {
        SetDamageData(tickData, damagePerTick * stacks);
    }
}