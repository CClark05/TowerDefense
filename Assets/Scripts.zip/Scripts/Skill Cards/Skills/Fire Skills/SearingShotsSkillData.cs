using UnityEngine;

[CreateAssetMenu(fileName = "Searing Shots Data", menuName = "SkillData/Fire/Searing Shots")]
public class SearingShotsSkillData : SkillData
{
    public override SkillInstance CreateInstance()
    {
        return new SearingShotsSkillInstance(this);
    }
}

public class SearingShotsSkillInstance : SkillInstance<SearingShotsSkillData>, IOnHit
{
    public SearingShotsSkillInstance(SearingShotsSkillData data) : base(data)
    {
    }

    public void OnHit(HitData hitData)
    {
        Data.statusEffects[0].Execute(hitData);
    }
}
