using System.Collections.Generic;
using System.Linq;

public abstract class SkillInstance
{
    protected SkillContext skillContext;
    public SkillData Data { get; }
    public bool PlayTwice;
    protected SkillInstance(SkillData data)
    {
        Data = data;
    }
    public void SetContext(SkillContext context) => skillContext = context;
}
public abstract class SkillInstance<TData> : SkillInstance where TData : SkillData
{
    protected new TData Data;
    protected SkillInstance(TData data) : base(data)
    {
        Data = data;
    }
}