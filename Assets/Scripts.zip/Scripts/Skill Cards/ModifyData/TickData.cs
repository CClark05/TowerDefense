using System.Collections;
using UnityEngine;

public class TickData
{
    public IDamageable damageable;
    public IUsesStatusEffects statusEffects;
    public int stacks;
    public float tickInterval;
    public float timer;
    public HitData hitData;
    public TickData(IDamageable damageable, IUsesStatusEffects statusEffects, TowerShooting tower, HitData hitData, float tickInterval)
    {
        this.damageable = damageable;
        this.statusEffects = statusEffects;
        this.tickInterval = tickInterval;
        this.hitData = hitData;
        stacks = 1;
    }
    
}
