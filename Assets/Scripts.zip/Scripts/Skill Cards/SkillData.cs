using UnityEditor;
using UnityEngine;

public enum CardRarity
{
    Common,
    Rare,
    Legendary,
}

public abstract class SkillData : ScriptableObject
{
    public int price;
    public string name;
    public Sprite icon;
    public CardRarity rarity;
    [TextArea] public string description;
    public StatusEffectData[] statusEffects;
    public SkillData[] prerequisiteSkills;
    public abstract SkillInstance CreateInstance();
}

