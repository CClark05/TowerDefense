using System;
using System.Collections;
using UnityEngine;

public class TowerShooting : MonoBehaviour
{
    private ProjectileData projectileData;
    private TowerDataHolder towerDataHolder;
    private float shootTimer;

    public event Action<int> OnDealDamage;
    public static event Action<Vector2, DamageData> OnDealDamageStatic;
    public event Action OnKillEnemy;

    private Coroutine shootCoroutine;
    private float timeBetweenShots => towerDataHolder.RuntimeData.timeBetweenShots;
    private float range => towerDataHolder.RuntimeData.Range;
    private void Awake()
    {
        towerDataHolder = GetComponent<TowerDataHolder>();
        projectileData = towerDataHolder.ProjectileData;
    }

    private void OnEnable()
    {
        EnemyStatusEffects.OnTakeDamageStatic += EnemyStatusEffectsOnTakeDamage;
    }

    private void EnemyStatusEffectsOnTakeDamage(DamageData data, Vector2 position)
    {
        Debug.Log("test");
        OnDealDamage?.Invoke(data.finalDamage);
        OnDealDamageStatic?.Invoke(position, data);
        if (data.didKill) OnKillEnemy?.Invoke();
    }

    private void Update()
    {
        shootTimer += Time.deltaTime;

        if (shootCoroutine != null && shootTimer >= timeBetweenShots)
        {
            shootTimer = timeBetweenShots;
            return;
        }

        if (shootCoroutine == null && shootTimer >= timeBetweenShots)
        {
            var closestEnemy = FindClosestEnemy();
            if (closestEnemy != null)
            {
                shootCoroutine = StartCoroutine(ShootProjectile());
                shootTimer = 0f;
            }
        }
    }

    private IEnumerator ShootProjectile()
    {
        var shotData = new ProjectileShotData(Time.time);
        yield return ProjectileService.ModifyProjectile(shotData, towerDataHolder.SkillContext);
        var target = FindClosestEnemy();
        if (target != null && target.TryGetComponent<IDamageable>(out var damageable))
        {
            var projectile = Projectile.CreateProjectile(projectileData, shotData, transform.position, damageable, towerDataHolder);

            projectile.OnDealDamage += (HitData hitData, Vector2 pos) =>
            {
                OnDealDamage?.Invoke(hitData.finalDamage);
                OnDealDamageStatic?.Invoke(pos, hitData);
                if (hitData.didKill) OnKillEnemy?.Invoke();
            };
        }

        shootCoroutine = null;
    }

    private GameObject FindClosestEnemy()
    {
        var enemies = EnemyManager.Instance.CurrentEnemies;
        (GameObject enemy, float dist) best = (null, Mathf.Infinity);

        foreach (var e in enemies)
        {
            if (e == null) continue;
            float d = Vector2.Distance(transform.position, e.transform.position);
            if (d < best.dist && d <= range)
            {
                best.enemy = e;
                best.dist = d;
            }
        }
        return best.enemy;
    }

    private void OnDisable()
    {
        if (shootCoroutine != null)
        {
            StopCoroutine(shootCoroutine);
            shootCoroutine = null;
        }
        EnemyStatusEffects.OnTakeDamageStatic -= EnemyStatusEffectsOnTakeDamage;
    }
}