using System;
using System.Linq;
using UnityEngine;

public class Projectile : MonoBehaviour
{
    [SerializeField] private ProjectileData data;
    private IDamageable target;
    private TowerDataHolder towerData;

    private Vector2 direction;
    private Vector2 targetOrigin;
    public event Action<HitData, Vector2> OnDealDamage;

    private void Init(IDamageable target, ProjectileShotData shotData)
    {
        GetComponent<ProjectileVisual>().SetColor(shotData.projectileColor);
        targetOrigin = target.Transform.position;
        direction = (targetOrigin - (Vector2)transform.position).normalized;
        this.target = target;
        
    }

    public static Projectile CreateProjectile(ProjectileData data, ProjectileShotData shotData, Vector2 position, IDamageable target, TowerDataHolder tower)
    {
        var projectile = Instantiate(data.prefab, position, Quaternion.identity).GetComponent<Projectile>();
        projectile.Init(target, shotData);
        projectile.towerData = tower;
        return projectile;
    }

    private void Update()
    {
        if (target == null) return;
        transform.position += (Vector3)direction * (data.speed * Time.deltaTime);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.GetComponent<IDamageable>() == null) return;
        var damageable = other.GetComponent<IDamageable>();
        var statusEffects = other.GetComponent<IUsesStatusEffects>();
        if (other.GetComponent<IUsesShields>() != null)
        {
            if (other.GetComponent<IUsesShields>().TryRemoveShield(1))
            {
                Destroy(gameObject);
                return;
            }
        }
        int baseDamage = data.damage + towerData.Data.damage;
        var hitData = new HitData(baseDamage, towerData.GetComponent<TowerShooting>(), damageable, statusEffects);
        bool delayed = false;
        hitData.DelayDamage = (float delay, float multiplier) =>
        {
            delayed = true;
            CoroutineRunner.Instance.StartCoroutine(
                DamageService.ApplyDelayedDamage(hitData, damageable, statusEffects, towerData.SkillContext, delay, multiplier, OnDealDamage));
        };
        var list = towerData.SkillContext.GetSkillInstancesWith<IOnHit>();
        foreach (var mod in towerData.SkillContext.GetSkillInstancesWith<IOnHit>().OrderBy(p => p.modifier.Priority)) 
        {
            mod.modifier.OnHit(hitData);
            if (mod.instance.PlayTwice)
                mod.modifier.OnHit(hitData);
        }
        if (delayed)
        {
            Destroy(gameObject);
            return;
        }

        DamageService.ApplyDamage(hitData, damageable, statusEffects, towerData.SkillContext, OnDealDamage);
        Destroy(gameObject);
    }
}