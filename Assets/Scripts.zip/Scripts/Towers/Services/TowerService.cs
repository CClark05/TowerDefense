
public static class TowerService
{
    public static void ModifyWaveStart(TowerWaveData data, SkillContext context)
    {
        foreach (var mod in context.GetSkillInstancesWith<ITowerWaveStartModifier>())
        {
            mod.modifier.Modify(data);
            if (mod.instance.PlayTwice)
                mod.modifier.Modify(data);
        }
    }

    public static void ModifyWaveEnd(TowerWaveData data, SkillContext context)
    {
        foreach (var mod in context.GetSkillInstancesWith<ITowerWaveEndModifier>())
        {
            mod.modifier.Modify(data);
            if (mod.instance.PlayTwice)
                mod.modifier.Modify(data);
        }
    }

    public static bool TryModifyOnCardReceived(TowerWaveData data, SkillInstance skillInstance)
    {
        if (skillInstance is ITowerCardReceivedModifier modifier)
        {
            modifier.Modify(data);
            if(skillInstance.PlayTwice)
                modifier.Modify(data);
            return true;
        }
        return false;
    }
    
    public static bool TryModifyOnCardRemoved(TowerWaveData data, SkillInstance skillInstance)
    {
        if (skillInstance is ITowerCardRemovedModifier modifier)
        {
            modifier.Modify(data);
            if(skillInstance.PlayTwice)
                modifier.Modify(data);
            return true;
        }
        return false;
    }
}