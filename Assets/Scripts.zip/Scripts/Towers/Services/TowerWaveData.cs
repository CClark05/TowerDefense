using System.Collections.Generic;

public class TowerWaveData
{
    public List<SkillData> addedCards = new();
    public List<SkillData> removedCards = new();
    public float increasedRange;
    public int increasedSlots;
}