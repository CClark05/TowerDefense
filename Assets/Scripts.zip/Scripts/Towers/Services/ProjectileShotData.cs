using UnityEngine;

public class ProjectileShotData
{
    public Color projectileColor = Color.white;
    public int plusDamage;
    private float releaseTime;
    public float AirTime => Time.time - releaseTime;
    public ProjectileShotData(float releaseTime)
    {
        this.releaseTime = releaseTime;
    }
}