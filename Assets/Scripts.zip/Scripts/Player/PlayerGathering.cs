using System;
using UnityEngine;

public class PlayerGathering : MonoBehaviour
{
    private PlayerCursor cursor;
    public event Action OnGather;
    private void Awake()
    {
        cursor = GetComponent<PlayerCursor>();
    }
    private void Update()
    {
        if (Input.GetMouseButtonDown(0) && cursor.CurrentHoveredObject != null && !BuildingManager.Instance.IsBuildMode && GetComponent<PlayerTurnManager>().MovesRemaining > 0)
        {
                cursor.CurrentHoveredObject.OnClick();
                if(cursor.CurrentHoveredObject is Resource)
                    OnGather?.Invoke();
        }
    }
}