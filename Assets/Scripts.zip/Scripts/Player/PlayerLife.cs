using System;
using UnityEngine;
using UnityEngine.Rendering;

public class PlayerLife : Singleton<PlayerLife>
{
    private int currentLives;
    public int CurrentLives
    {
        get => currentLives;
        set
        {
            if (Equals(value, currentLives)) return;
            currentLives = value;
            OnLivesUpdated?.Invoke(value);
        }
    }
    public event Action<int> OnLivesUpdated;
    public event Action<GameOverData> OnGameOver;
    private void Start()
    {
        CurrentLives = LevelDataHolder.Instance.Data.playerLives;
        EnemyMovement.OnReachedEndStatic += OnEnemyReachedEndStatic;
    }

    private void OnEnemyReachedEndStatic(int lives)
    {
        if (CurrentLives == 0) return;
        CurrentLives = Mathf.Max(0, currentLives - lives);
        if (CurrentLives == 0)
        {
            Debug.Log("GAME OVER");
            OnGameOver?.Invoke( PlayerGameOverStats.GetGameOverData());
        }
    }

    private void OnDestroy()
    {
        EnemyMovement.OnReachedEndStatic -= OnEnemyReachedEndStatic;
    }
}
