using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class StatusEffectUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI stacksText;
    private int stacks;
     public StatusEffectData Data { get; private set; }

    public void Init(StatusEffectData data, int stacks)
    {
        this.Data = data;
        GetComponent<Image>().sprite = data.sprite;
        this.stacks = stacks;
        stacksText.text = stacks.ToString();
    }

    public void AddStacks(int amount)
    {
        stacks += amount;
        stacksText.text = stacks.ToString();
    }
}
