using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class CardIconUI : MonoBehaviour
{
    [SerializeField] private Image image;
    [SerializeField] private Image selectionOutline;
    [SerializeField] private Button_Scale_Hover button;
    [SerializeField] private Image redOutline;
    public Button_Scale_Hover Button { get; private set; }
    public SkillInstance SkillInstance { get; private set; }
    public IUsesCards usesCards { get; private set; }
    private bool selected;
    private SkillContext skillContext;
    public bool Selected
    {
        get => selected;
        set
        {
            if (selected == value) return;
            selected = value;
            UpdateVisual();
        }
    }

    public void Init(SkillInstance instance, IUsesCards usesCards)
    {
        Debug.Log($"INIT {instance.PlayCount} (inst={instance.GetHashCode()})");
        Button = button;
        SkillInstance = instance;
        this.usesCards = usesCards;
        image.sprite = instance.Data.icon;
        skillContext = GetComponentInParent<TowerDataHolder>().SkillContext;
        SkillInstance.OnPlayCountUpdated += CardPlayCountUpdated;
        redOutline.gameObject.SetActive(instance.PlayCount > 1);
        if (ColorUtility.TryParseHtmlString("#75a743", out Color greenColor))
            GetComponent<CardIconDragDrop>().OnIsOverReceiverUpdated += isOver =>
            {
                if (isOver)
                {
                    selectionOutline.color = greenColor;
                    return;
                }

                selectionOutline.color = Color.white;
            };
    }
    private void CardPlayCountUpdated(int playCount)
    {
        Debug.Log("update " + playCount);
        redOutline.gameObject.SetActive(playCount > 1);
    }
    private void UpdateVisual()
    {
        Button.ToggleScaleAnimation(selected);
        if (!selected) Button.ScaleBackToNormal();
        selectionOutline.gameObject.SetActive(selected);
    }

    private void OnDestroy()
    {
        SkillInstance.OnPlayCountUpdated -= CardPlayCountUpdated;
    }
}