using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CardIconUI : MonoBehaviour
{
    [SerializeField] private Image image;
    [SerializeField] private Image selectionOutline;
    [SerializeField] private Button_Scale_Hover button;
    public Button_Scale_Hover Button { get; private set; }
    public SkillData SkillData { get; private set; }
    public IUsesCards usesCards { get; private set; }
    private bool selected;

    public bool Selected
    {
        get => selected;
        set
        {
            if (selected == value) return;
            selected = value;
            UpdateVisual();
        }
    }

    public void Init(SkillData skillData, IUsesCards usesCards)
    {
        Button = button;
        SkillData = skillData;
        this.usesCards = usesCards;
        image.sprite = skillData.icon;
        //UpdateVisual();
        if (ColorUtility.TryParseHtmlString("#75a743", out Color greenColor))
            GetComponent<CardIconDragDrop>().OnIsOverReceiverUpdated += isOver =>
            {
                if (isOver)
                {
                    selectionOutline.color = greenColor;
                    return;
                }
                selectionOutline.color = Color.white;
            };
    }

    private void UpdateVisual()
    {
        Button.ToggleScaleAnimation(selected);
        if (!selected) Button.ScaleBackToNormal();
        selectionOutline.gameObject.SetActive(selected);
    }
}