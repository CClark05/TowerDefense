using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class CardPreviewUI : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI nameText, descriptionText;
    [SerializeField] private VerticalLayoutGroup statusEffectGroup;
    [SerializeField] private GameObject statusEffectPrefab;
    private List<GameObject> activeStatusEffects = new();
    public void SetSkill(SkillData data)
    {
        activeStatusEffects.ForEach(Destroy);
        int sellPrice = Mathf.FloorToInt(data.price * 0.5f);
        nameText.text = data.name;
        descriptionText.text = data.description;
        foreach (var effect in data.statusEffects)
        {
            var newEffect = Instantiate(statusEffectPrefab, statusEffectGroup.transform);
            newEffect.GetComponent<TextMeshProUGUI>().text = effect.name;
            newEffect.GetComponent<TextMeshProUGUI>().color = effect.color;
            newEffect.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = effect.description;
            activeStatusEffects.Add(newEffect);
        }
    }
}