using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class SetCardData : MonoBehaviour
{
    [SerializeField] private TextMeshProUGUI nameText, descriptionText, sellPriceText;
    [SerializeField] private VerticalLayoutGroup statusEffectGroup;
    [SerializeField] private SkillData skillData;
    [SerializeField] private GameObject statusEffectPrefab;
    public SkillData SkillData => skillData;
    public int SellPrice { get; private set; }
    private List<GameObject> currentStatusEffects = new();
    private void Awake()
    {
        UpdateVisual();
    }
    private void UpdateVisual()
    {
        SellPrice = Mathf.FloorToInt(skillData.price * 0.5f);
        nameText.text = skillData.name;
        descriptionText.text = skillData.description;
        sellPriceText.text = $"$ {SellPrice}";
        foreach (var effect in currentStatusEffects)
        {
            Destroy(effect);
        }
        currentStatusEffects.Clear();
        foreach (var effect in skillData.statusEffects)
        {
            var newEffect = Instantiate(statusEffectPrefab, statusEffectGroup.transform);
            newEffect.GetComponent<TextMeshProUGUI>().text = effect.name;
            newEffect.GetComponent<TextMeshProUGUI>().color = effect.color;
            newEffect.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = effect.description;
            currentStatusEffects.Add(newEffect);
        }
    }
    public void SetData(SkillData data)
    {
        skillData = data;
        UpdateVisual();
    }
}