using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class EnemyStatusEffects : MonoBehaviour, IUsesStatusEffects
{
    [SerializeField] private GameObject statusEffectPrefab;
    [SerializeField] private GridLayoutGroup layoutGroup;
    public Dictionary<PersistentStatusEffect, int> PersistentEffectsApplied { get; } = new();
    private List<StatusEffectUI> activeEffectUI = new();
    private Dictionary<OnTickStatusEffect, TickData> OnTickEffects = new();
    public Action<DamageData> OnTakeDamage { get; set; }
    public static event Action<DamageData, Vector2> OnTakeDamageStatic;

    private void Start()
    {
        OnTakeDamage += data =>
        {
            Debug.Log("test2");
            OnTakeDamageStatic?.Invoke(data, transform.position);
        };
    }

    public void AddPersistentEffect(PersistentStatusEffect effect, HitData hitData, int stacks)
    {
        if (effect is OnTickStatusEffect tickEffect)
        {
            if (!OnTickEffects.ContainsKey(tickEffect))
            {
                TickData tickData = new TickData(GetComponent<IDamageable>(), this, hitData.tower, hitData, tickEffect.tickInterval);
                OnTickEffects[tickEffect] = tickData;
            }
            else
                OnTickEffects[tickEffect].stacks++;
        }

        PersistentEffectsApplied[effect] = PersistentEffectsApplied.GetValueOrDefault(effect) + stacks;
        var effectUI = activeEffectUI.Find(e => e.Data == effect);
        if (effectUI != null)
        {
            effectUI.AddStacks(stacks);
            return;
        }

        var newEffect = Instantiate(statusEffectPrefab, layoutGroup.transform).GetComponent<StatusEffectUI>();
        newEffect.Init(effect, stacks);
        activeEffectUI.Add(newEffect);
    }

    public void RemoveAllStacks(PersistentStatusEffect effect)
    {
        var effectUI = activeEffectUI.Find(e => e.Data == effect);
        PersistentEffectsApplied.Remove(effect);
        if (effect is OnTickStatusEffect onTick)
            OnTickEffects.Remove(onTick);
        activeEffectUI.Remove(effectUI);
        Destroy(effectUI.gameObject);
    }

    public void RemoveStacks(PersistentStatusEffect effect, int stacks)
    {
        if (!PersistentEffectsApplied.TryGetValue(effect, out int current)) return;

        PersistentEffectsApplied[effect] = Mathf.Max(0, current - stacks);
        if (effect is OnTickStatusEffect onTick)
            OnTickEffects[onTick].stacks = Mathf.Max(0, OnTickEffects[onTick].stacks - stacks);
        if (PersistentEffectsApplied[effect] == 0)
        {
            RemoveAllStacks(effect);
        }
    }

    private void Update()
    {
        Tick();
    }

    private void Tick()
    {
        foreach (var kvp in OnTickEffects)
        {
            var tickData = kvp.Value;
            tickData.timer += Time.deltaTime;
            if (tickData.timer >= tickData.tickInterval)
            {
                tickData.timer = 0;
                kvp.Key.OnTick(tickData, tickData.stacks);
            }
        }
    }
}