using System;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMovement : MonoBehaviour
{
    private List<Vector2> path;
    private int currentIndex;
    private float moveSpeed;
    public static event Action<int> OnReachedEndStatic;
    public event Action OnReachedEnd;
    private void Start()
    {
        moveSpeed = GetComponent<EnemyDataHolder>().Data.speed;
        path = AStarPathfinding.Instance.GetPath();
        if(path == null) Debug.LogError("No path found");
    }
    private void Update()
    {
        if (currentIndex >= path.Count)
        {
            OnReachedEndStatic?.Invoke(GetComponent<EnemyDataHolder>().Data.livesCost);
            OnReachedEnd?.Invoke();
            Destroy(gameObject);
            return;
        }
        
        Vector2 target = path[currentIndex];
        Vector2 direction = (target - (Vector2)transform.position).normalized;
        transform.position += (Vector3)(direction * (moveSpeed * Time.deltaTime));

        if (Vector2.Distance(transform.position, target) < 0.1f)
            currentIndex++;
    }
}
