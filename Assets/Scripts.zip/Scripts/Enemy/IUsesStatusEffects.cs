using System;
using System.Collections.Generic;
using UnityEngine;

public interface IUsesStatusEffects
{
    public Dictionary<PersistentStatusEffect, int> PersistentEffectsApplied { get; }
    public void AddPersistentEffect(PersistentStatusEffect effect, HitData hitData, int stacks);
    public void RemoveAllStacks(PersistentStatusEffect effect);
    public void RemoveStacks(PersistentStatusEffect effect, int stacks);
    public Action<DamageData> OnTakeDamage { get; set; }
}