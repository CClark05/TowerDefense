using System;
using UnityEngine;

public class EnemyHealth : MonoBehaviour, IDamageable, IUsesHealth
{
    public HealthSystem healthSystem { get; private set; }
    public Transform Transform => transform;
    public event Action OnDeath;
    private void Awake()
    {
        healthSystem = new HealthSystem(GetComponent<EnemyDataHolder>().Data.health);
    }

    public bool TakeDamage(int amount)
    {
        bool isDead = healthSystem.Damage(amount);
        if (isDead)
        {
            OnDeath?.Invoke();
            Destroy(gameObject);
        }
        return isDead;
    }


    
}