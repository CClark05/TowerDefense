public interface IUsesHealth
{
    public HealthSystem healthSystem { get; }
}